export interface Player {
  name: string;
  country: string;
  shirtNumber: number | string;
  position: string;
}
